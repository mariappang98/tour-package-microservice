package com.tour.management.tour_package.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TourPackageDto {
    @NotBlank(message = "Location cannot be blank")
    private String location;

    @Pattern(regexp = "^(100|[1-9]?[0-9])$", message = "Discount must be between 0 and 100")
    private String discountInPercentage;

    @NotBlank(message = "Title is required")
    @Size(max = 100, message = "Title cannot exceed 100 characters")
    private String title;

    @NotBlank(message = "Description is required")
    @Size(max = 500, message = "Description cannot exceed 500 characters")
    private String description;

    @NotBlank(message = "Duration is required")
    private String duration;

    @NotBlank(message = "Actual price is required")
    @Pattern(regexp = "^[0-9]+(\\.[0-9]{1,2})?$", message = "Actual price must be a valid number")
    private String actualPrice;

    @NotBlank(message = "Discounted price is required")
    @Pattern(regexp = "^[0-9]+(\\.[0-9]{1,2})?$", message = "Discounted price must be a valid number")
    private String discountedPrice;
}

