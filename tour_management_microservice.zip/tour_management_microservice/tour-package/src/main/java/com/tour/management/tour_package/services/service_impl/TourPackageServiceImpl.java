package com.tour.management.tour_package.services.service_impl;

import com.tour.management.tour_package.config.APIResponse;
import com.tour.management.tour_package.config.S3Config;
import com.tour.management.tour_package.constants.Messages;
import com.tour.management.tour_package.dto.RequestUpdateTourPackage;
import com.tour.management.tour_package.dto.TourPackageDto;
import com.tour.management.tour_package.entity.Customer;
import com.tour.management.tour_package.entity.TourPackage;
import com.tour.management.tour_package.exception.GlobalExceptionHandler;
import com.tour.management.tour_package.repo.CutomerRepo;
import com.tour.management.tour_package.repo.TourPackageRepo;
import com.tour.management.tour_package.services.service.TourPackageService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@Service
@RequiredArgsConstructor
public class TourPackageServiceImpl implements TourPackageService {

    private static final Logger LOGGER
            = LoggerFactory.getLogger(TourPackageServiceImpl.class);

    private final TourPackageRepo tourPackageRepo;

    private final CutomerRepo customerRepo;

    private final S3Config s3Client;

    @Value("${aws.s3.bucket}")
    private String bucketName;

    @Override
    public ResponseEntity<APIResponse> createNewTourPackageWithLocation(TourPackageDto tourPackageDto, String userName) {

        String exitUserName = customerRepo.findAll().stream()
                .map(Customer::getUserName)
                .filter(userName::equals).findFirst().orElse(null);
        boolean userExists = true;
        if (exitUserName != null) userExists = tourPackageRepo.findAll().stream()
                .anyMatch(data -> data.getLocation().equals(tourPackageDto.getLocation()));

        if (!userExists) {
            TourPackage newCustomer = new TourPackage();
            newCustomer.setLocation(tourPackageDto.getLocation());
            newCustomer.setTitle(tourPackageDto.getTitle());
            newCustomer.setDescription(tourPackageDto.getDescription());
            newCustomer.setDuration(tourPackageDto.getDuration());
            newCustomer.setActualPrice(tourPackageDto.getActualPrice());
            newCustomer.setDiscountedPrice(tourPackageDto.getDiscountedPrice());
            newCustomer.setDiscountInPercentage(tourPackageDto.getDiscountInPercentage());
            newCustomer.setCreatedAt(System.currentTimeMillis() / 1000);
            newCustomer.setUserName(userName);

            if (tourPackageDto.getLocation() != null) tourPackageRepo.save(newCustomer);

            LOGGER.info("New tour package created successfully: {}", newCustomer.getLocation());
            return ResponseEntity.status(HttpStatus.CREATED).body(new APIResponse(Messages.TOUR_LOCATION_CREATION_SUCCESS, new ArrayList<>()));
        } else {
            LOGGER.error("Tour package failed: User already exists - {}", tourPackageDto.getLocation());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.LOCATION_ALREADY_EXISTS)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }
    }

    @Override
    public ResponseEntity<APIResponse> updateExitTourPackage(RequestUpdateTourPackage requestUpdateTourPackage, String userName) {
        String exitUserName = customerRepo.findAll().stream()
                .map(Customer::getUserName)
                .filter(userName::equals).findFirst().orElse(null);
        TourPackage exittTourPackage = null;

        if (exitUserName != null) exittTourPackage = tourPackageRepo.findAll().stream()
                .filter(data -> data.getId().equals(requestUpdateTourPackage.getId()) &&
                        data.getUserName().equals(userName))
                .findAny().orElse(null);

        if (exittTourPackage != null) {
            exittTourPackage.setLocation(requestUpdateTourPackage.getLocation());
            exittTourPackage.setTitle(requestUpdateTourPackage.getTitle());
            exittTourPackage.setDescription(requestUpdateTourPackage.getDescription());
            exittTourPackage.setDuration(requestUpdateTourPackage.getDuration());
            exittTourPackage.setActualPrice(requestUpdateTourPackage.getActualPrice());
            exittTourPackage.setDiscountedPrice(requestUpdateTourPackage.getDiscountedPrice());
            exittTourPackage.setDiscountInPercentage(requestUpdateTourPackage.getDiscountInPercentage());
            exittTourPackage.setCreatedAt(System.currentTimeMillis() / 1000);

            tourPackageRepo.save(exittTourPackage);

            LOGGER.info("Update tour package created successfully: {}", exittTourPackage.getLocation());
            return ResponseEntity.status(HttpStatus.OK).body(new APIResponse(Messages.UPDATE_TOUR_PACKAGE_DATA, new ArrayList<>()));
        } else {
            LOGGER.error("Tour package failed: User does not exists - {}", requestUpdateTourPackage.getLocation());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.USER_DOES_NOT_EXIST)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }
    }

    @Override
    public ResponseEntity<APIResponse> deleteExitTourPackage(Integer id, String userName) {
        String exitUserName = customerRepo.findAll().stream()
                .map(Customer::getUserName)
                .filter(userName::equals).findFirst().orElse(null);

        boolean exitTourPackage = true;
        if (exitUserName != null) exitTourPackage = tourPackageRepo.findAll().stream()
                .anyMatch(data -> data.getId().equals(id) && data.getUserName().equals(userName));

        if (exitTourPackage) {
            tourPackageRepo.deleteById(id);
            LOGGER.info("Delete tour package successfully: {}", id);
            return ResponseEntity.status(HttpStatus.OK).body(new APIResponse(Messages.DELETE_TOUR_PACKAGE_DATA, new ArrayList<>()));
        } else {
            LOGGER.error("Unexpected error while deleting tour package: {}", id);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.TOUR_PACKAGE_DATA_DOES_NOT_EXIST)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }
    }

    @Override
    public ResponseEntity<APIResponse> listAllPackages(String userName) {
        String exitUserName = customerRepo.findAll().stream()
                .map(Customer::getUserName)
                .filter(userName::equals).findFirst().orElse(null);

        List<TourPackage> exitTourPackage = new ArrayList<>();

        if (exitUserName != null)
            exitTourPackage = tourPackageRepo.findAll().stream().filter(data ->
                    data.getUserName().equals(userName)).toList();

        if (!exitTourPackage.isEmpty()) {
            LOGGER.info("Fetch tour package successfully: {}", new ArrayList<>());
            return ResponseEntity.status(HttpStatus.OK).body(new APIResponse(Messages.FETCH_TOUR_PACKAGE_DATA, exitTourPackage));
        } else {
            LOGGER.error("Unexpected error while fetching tour package: {}", new ArrayList<>());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.TOUR_PACKAGE_DATA_DOES_NOT_EXIST)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }
    }

    @Override
    public ResponseEntity<APIResponse> getTourPackageById(Integer id, String userName) {
        String exitUserName = customerRepo.findAll().stream()
                .map(Customer::getUserName)
                .filter(userName::equals).findFirst().orElse(null);
        TourPackage exittTourPackage = null;

        if (exitUserName != null) exittTourPackage = tourPackageRepo.findAll().stream()
                .filter(data -> data.getId().equals(id) &&
                        data.getUserName().equals(userName)).findAny().orElse(null);
        if (exittTourPackage != null) {
            LOGGER.info("Fetch tour package successfully by id: {}", id);
            return ResponseEntity.status(HttpStatus.OK).body(new APIResponse(Messages.FETCH_TOUR_PACKAGE_DATA, exittTourPackage));
        } else {
            LOGGER.error("Unexpected error while fetching tour package by id: {}", id);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.TOUR_PACKAGE_DATA_DOES_NOT_EXIST)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }
    }

    @Override
    public ResponseEntity<APIResponse> getTourPackageByLocation(String location, String userName) {
        String exitUserName = customerRepo.findAll().stream()
                .map(Customer::getUserName)
                .filter(userName::equals).findFirst().orElse(null);
        TourPackage exittTourPackage = null;

        if (exitUserName != null) exittTourPackage = tourPackageRepo.findAll().stream()
                .filter(data -> data.getLocation().equals(location) &&
                        data.getUserName().equals(userName)).findAny().orElse(null);

        if (exittTourPackage != null) {
            LOGGER.info("Fetch tour package successfully by location: {}", location);
            return ResponseEntity.status(HttpStatus.OK).body(new APIResponse(Messages.FETCH_TOUR_PACKAGE_DATA, exittTourPackage));
        } else {
            LOGGER.error("Unexpected error while fetching tour package by location: {}", location);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.TOUR_PACKAGE_DATA_DOES_NOT_EXIST)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }
    }


    @Override
    public ResponseEntity<APIResponse> uploadTourImage(MultipartFile image, Integer id, String userName) {
        String key = System.currentTimeMillis() + "_" + image.getOriginalFilename();

        try {
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .contentType(image.getContentType())
                    .build();

            s3Client.s3Client().putObject(putObjectRequest, RequestBody.fromBytes(image.getBytes()));
        } catch (Exception e) {
            LOGGER.error("Unexpected error while upload tour image by id: {}", image);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.UNABLE_TO_UPLOADED_IMAGE)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }
        String exitUserName = customerRepo.findAll().stream()
                .map(Customer::getUserName)
                .filter(userName::equals).findFirst().orElse(null);
        TourPackage userExists = null;

        if (exitUserName != null) userExists = tourPackageRepo.findAll().stream()
                .filter(data -> data.getId().equals(id) &&
                        data.getUserName().equals(userName)).findAny().orElse(null);
        String imageUrl = generatePresignedUrl(bucketName, key);
        if (userExists != null) {
            if (imageUrl != null) {
                userExists.setImage(imageUrl);
            } else {
                userExists.setImage("");
            }
            userExists.setUpdatedAt(System.currentTimeMillis() / 1000);

            tourPackageRepo.save(userExists);

            LOGGER.info("Tour image upload: {}", userExists.getLocation());
            return ResponseEntity.status(HttpStatus.OK).body(new APIResponse(Messages.TOUR_IMAGE_UPLOADED, new ArrayList<>()));
        } else {
            LOGGER.error("Unexpected error while upload tour image by id: {}", imageUrl);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.TOUR_PACKAGE_DATA_DOES_NOT_EXIST)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }
    }

    public String generatePresignedUrl(String bucketName, String key) {
        S3Presigner presigner = S3Presigner.create();

        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .build();

        GetObjectPresignRequest presignRequest = GetObjectPresignRequest.builder()
                .signatureDuration(Duration.ofMinutes(15))
                .getObjectRequest(getObjectRequest)
                .build();

        return presigner.presignGetObject(presignRequest).url().toString();
    }

}
