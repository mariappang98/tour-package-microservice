package com.tour.management.tour_package.exception;


import com.tour.management.tour_package.config.ErrorResponse;
import com.tour.management.tour_package.constants.Messages;
import jakarta.persistence.EntityNotFoundException;
import jakarta.ws.rs.NotFoundException;
import org.apache.http.auth.AuthenticationException;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.nio.file.AccessDeniedException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;


@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Random random = new Random();
    private Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(err ->
                errors.put(err.getField(), err.getDefaultMessage())
        );
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ErrorResponse.builder()
                .errorCode(generateRandomErrorCode("ERR_"))
                .message(Messages.API_METHOD_ARGUMENT_ERROR)
                .errors(errors)
                .timestamp(LocalDateTime.now().toString())
                .path(getCurrentRequestPath())
                .build());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleConstraintViolation(ConstraintViolationException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getConstraintViolations().forEach(cv -> {
            String paramName = cv.getPropertyPath().toString();
            if (paramName.contains(".")) {
                paramName = paramName.substring(paramName.lastIndexOf('.') + 1);
            }
            errors.put(paramName, cv.getMessage());
        });
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ErrorResponse.builder()
                .errorCode(generateRandomErrorCode("ERR_"))
                .message(Messages.API_METHOD_ARGUMENT_ERROR)
                .errors(errors)
                .timestamp(LocalDateTime.now().toString())
                .path(getCurrentRequestPath())
                .build());
    }


    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleAllExceptions(Exception ex) {
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        String message = ex.getMessage();

        // Map specific exceptions to status and message
        if (ex instanceof EntityNotFoundException) {
            status = HttpStatus.NOT_FOUND;
            message = Messages.ENTITY_NOT_FOUND_EXCEPTION;
        } else if (ex instanceof HttpRequestMethodNotSupportedException) {
            status = HttpStatus.METHOD_NOT_ALLOWED;
            message = Messages.METHOD_NOT_ALLOWED;
        } else if (ex instanceof IllegalArgumentException) {
            status = HttpStatus.BAD_REQUEST;
            message = Messages.INVALID_ARGUMENTS_EXCEPTION;
        } else if (ex instanceof NotFoundException) {
            status = HttpStatus.NOT_FOUND;
            message = Messages.NO_RESULT_FOUND_EXCEPTION;
        } else if (ex instanceof DataIntegrityViolationException) {
            status = HttpStatus.CONFLICT;
            message = Messages.DATA_INTEGRITY_EXCEPTION;
        } else if (ex instanceof HttpMessageNotReadableException) {
            status = HttpStatus.BAD_REQUEST;
            message = Messages.MALFORMED_JSON_EXCEPTION;
        } else if (ex instanceof NoSuchElementException) {
            status = HttpStatus.BAD_REQUEST;
            message = Messages.NO_SUCH_ELEMENT_EXCEPTION;
        } else if (ex instanceof NoHandlerFoundException) {
            status = HttpStatus.BAD_REQUEST;
            message = ex.getMessage();
        } else if (ex instanceof ConstraintViolationException) {
            status = HttpStatus.BAD_REQUEST;
            message = Messages.CONSTRAINT_VIOLATION_EXCEPTION;
        } else if (ex instanceof AuthenticationException) {
            status = HttpStatus.UNAUTHORIZED;
            message = Messages.AUTHENTICATION_FAILED_EXCEPTION;
        } else if (ex instanceof AccessDeniedException) {
            status = HttpStatus.FORBIDDEN;
            message = ex.getMessage();
        } else if (ex instanceof NoResourceFoundException || ex instanceof NoHandlerFoundException) {
            status = HttpStatus.NOT_FOUND;
            message = Messages.ENDPOINT_NOT_FOUND_EXCEPTION;
        }

        ErrorResponse errorResponse = ErrorResponse.builder()
                .errorCode(generateRandomErrorCode("ERR_"))
                .message(message)
                .timestamp(LocalDateTime.now().toString())
                .path(getCurrentRequestPath())
                .build();

        return ResponseEntity.status(status).body(errorResponse);
    }

    public static String getCurrentRequestPath() {
        ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        return (attrs != null) ? attrs.getRequest().getRequestURI() : "N/A";
    }

    public static String generateRandomErrorCode(String prefix) {
        int randomPart = random.nextInt(10000); // Generates number between 0 and 9999
        return String.format("%s_%04d", prefix, randomPart);
    }

}
