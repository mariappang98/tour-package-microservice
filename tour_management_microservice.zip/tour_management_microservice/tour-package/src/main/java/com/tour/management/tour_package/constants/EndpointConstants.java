package com.tour.management.tour_package.constants;

public class EndpointConstants {

    public static final  String BASE_URL = "/api/tours";

    public static final  String ADD_TOUR_PACKAGE = "/add/packages";

    public static final  String UPDATE_TOUR_PACKAGE = "/update/packages";

    public static final  String GET_TOUR_PACKAGE_ID = "/packagess";

    public static final  String GET_TOUR_PACKAGE_LOCATION = "/packages/{location}";

    public static final  String DELETE_TOUR_PACKAGE = "/delete/packages/{id}";

    public static final  String GET_ALL_TOUR_PACKAGE = "/packages";

    public static final  String UPLOAD_TOUR_PACKAGE_IMAGE = "/upload";

}
