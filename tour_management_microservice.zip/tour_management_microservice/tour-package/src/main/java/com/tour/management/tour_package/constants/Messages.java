package com.tour.management.tour_package.constants;

public class Messages {
    // Prevent instantiation
    private Messages() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
    // Error Response messages
    public static final String API_METHOD_ARGUMENT_ERROR = "Invalid method argument(s) provided. Please check the request parameters or payload.";
    public static final String API_CALL_ERROR = "An unexpected error occurred while processing the request.";
    public static final String ENTITY_NOT_FOUND_EXCEPTION = "The requested entity was not found.";
    public static final String INVALID_ARGUMENTS_EXCEPTION = "Invalid arguments provided.";
    public static final String METHOD_NOT_ALLOWED = "The requested HTTP method is not allowed for this endpoint.";
    public static final String NO_RESULT_FOUND_EXCEPTION = "No result found for the request.";
    public static final String DATA_INTEGRITY_EXCEPTION = "Data integrity violation.";
    public static final String MALFORMED_JSON_EXCEPTION = "Malformed JSON request.";
    public static final String NO_SUCH_ELEMENT_EXCEPTION = "Element not found.";
    public static final String CONSTRAINT_VIOLATION_EXCEPTION = "Constraint violation occurred.";
    public static final String AUTHENTICATION_FAILED_EXCEPTION = "Authentication failed.";
    public static final String ENDPOINT_NOT_FOUND_EXCEPTION = "The requested endpoint was not found or Path variable is missing.!";
    public static final String USER_DOES_NOT_EXIST = "User does not exist.";
    public static final String LOCATION_ALREADY_EXISTS = "Location already exists.";
    public static final String TOUR_PACKAGE_DATA_DOES_NOT_EXIST = "Tour package data does not exit..";
    public static final String UNABLE_TO_UPLOADED_IMAGE = "Unable to uploaded tour image..";


    // Success Response messages

    public static final String TOUR_LOCATION_CREATION_SUCCESS = "Tour location has been successfully created..!";
    public static final String TOUR_IMAGE_UPLOADED = "Tour image  has been successfully uploaded..!";
    public static final String DELETE_TOUR_PACKAGE_DATA = "Tour package data has been successfully deleted..!";
    public static final String UPDATE_TOUR_PACKAGE_DATA = "Tour package data has been successfully updated..!";
    public static final String FETCH_TOUR_PACKAGE_DATA = "Tour package data has been successfully fetched..!";


}

