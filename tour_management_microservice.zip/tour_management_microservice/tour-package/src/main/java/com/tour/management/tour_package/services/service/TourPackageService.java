package com.tour.management.tour_package.services.service;

import com.tour.management.tour_package.config.APIResponse;
import com.tour.management.tour_package.dto.RequestUpdateTourPackage;
import com.tour.management.tour_package.dto.TourPackageDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface TourPackageService {
    ResponseEntity<APIResponse> createNewTourPackageWithLocation(TourPackageDto tourPackageDto, String userName);

    ResponseEntity<APIResponse> updateExitTourPackage(RequestUpdateTourPackage requestUpdateTourPackage, String userName);

    ResponseEntity<APIResponse> deleteExitTourPackage(Integer id, String userName);

    ResponseEntity<APIResponse> listAllPackages(String userName);

    ResponseEntity<APIResponse> getTourPackageById(Integer id, String userName);

    ResponseEntity<APIResponse> getTourPackageByLocation(String location, String userName);

    ResponseEntity<APIResponse> uploadTourImage(MultipartFile image, Integer id, String userName);
}
