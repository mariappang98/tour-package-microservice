package com.tour.management.tour_package.controller;


import com.tour.management.tour_package.config.APIResponse;
import com.tour.management.tour_package.constants.EndpointConstants;
import com.tour.management.tour_package.constants.VariableConstants;
import com.tour.management.tour_package.dto.RequestUpdateTourPackage;
import com.tour.management.tour_package.dto.TourPackageDto;
import com.tour.management.tour_package.services.service.TourPackageService;
import jakarta.validation.Valid;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping(EndpointConstants.BASE_URL)
@RequiredArgsConstructor
@Validated
public class TourPackageController {


    private final TourPackageService tourPackageService;


    @PostMapping(EndpointConstants.ADD_TOUR_PACKAGE)
    ResponseEntity<APIResponse> addNewTourPackageWithLocation(@Valid @RequestBody TourPackageDto tourPackageDto, @RequestParam(VariableConstants.USER_NAME) @NotBlank(message = "Username cannot be blank") String userName) {
        return tourPackageService.createNewTourPackageWithLocation(tourPackageDto,userName);
    }

    @PutMapping(EndpointConstants.UPDATE_TOUR_PACKAGE)
    ResponseEntity<APIResponse> updateExitTourPackage(@Valid @RequestBody RequestUpdateTourPackage requestUpdateTourPackage,@RequestParam(VariableConstants.USER_NAME) @NotBlank(message = "Username cannot be blank") String userName) {
        return tourPackageService.updateExitTourPackage(requestUpdateTourPackage,userName);
    }

    @DeleteMapping(EndpointConstants.DELETE_TOUR_PACKAGE)
    ResponseEntity<APIResponse> deleteExitTourPackage(@PathVariable(VariableConstants.ID)  Integer id, @RequestParam(VariableConstants.USER_NAME) @NotBlank(message = "Username cannot be blank") String userName) {
        return tourPackageService.deleteExitTourPackage(id,userName);
    }

    @GetMapping(EndpointConstants.GET_ALL_TOUR_PACKAGE)
    ResponseEntity<APIResponse> listAllPackages(@RequestParam(VariableConstants.USER_NAME) @NotBlank(message = "UserName cannot be blank") String userName) {
        return tourPackageService.listAllPackages(userName);
    }

    @GetMapping
    ResponseEntity<APIResponse> getTourPackageById(@RequestParam(VariableConstants.ID) @NotNull(message = "Id cannot be blank") Integer id, @RequestParam(VariableConstants.USER_NAME) @NotBlank(message = "Username cannot be blank") String userName) {
        return tourPackageService.getTourPackageById(id,userName);
    }

    @GetMapping(EndpointConstants.GET_TOUR_PACKAGE_LOCATION)
    ResponseEntity<APIResponse> getTourPackageByLocation(@PathVariable(VariableConstants.LOCATION) String location,  @RequestParam(VariableConstants.USER_NAME) @NotBlank(message = "Username cannot be blank") String userName) {
        return tourPackageService.getTourPackageByLocation(location,userName);
    }

    @PutMapping(EndpointConstants.UPLOAD_TOUR_PACKAGE_IMAGE)
    ResponseEntity<APIResponse> uploadImage(@RequestParam(VariableConstants.IMAGE) @NotNull(message = "Image cannot be blank") MultipartFile image,  @RequestParam(VariableConstants.ID) @NotNull(message = "Id cannot be blank") Integer id, @RequestParam(VariableConstants.USER_NAME) @NotBlank(message = "Username cannot be blank") String userName) {
        return tourPackageService.uploadTourImage(image,id,userName);
    }

}
