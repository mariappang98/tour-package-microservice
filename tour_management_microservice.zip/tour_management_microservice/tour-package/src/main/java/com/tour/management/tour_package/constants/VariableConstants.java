package com.tour.management.tour_package.constants;


public class VariableConstants {

    public static final String USER_NAME ="userName";

    public static final String LOCATION ="location";

    public static final String IMAGE ="image";

    public static final String ID ="id";

    public static final String TIMESTAMP ="timestamp";

    public static final String STATUS ="status";

    public static final String ERROR ="error";

    public static final String MESSAGE ="message";

    public static final String UNAUTHORIZED ="Unauthorized";

}
