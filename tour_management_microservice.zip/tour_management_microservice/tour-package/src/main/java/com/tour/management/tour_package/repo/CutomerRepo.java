package com.tour.management.tour_package.repo;

import com.tour.management.tour_package.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CutomerRepo extends JpaRepository<Customer,Integer> {

}
