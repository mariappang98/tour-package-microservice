package com.tour.management.tour_package.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "tour_package")
public class TourPackage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "image",length = 2000)
    private String image;

    @Column(name = "location")
    private String location;

    @Column(name = "discount_percentage")
    private String discountInPercentage;

    @Column(name = "title")
    private String title;

    @Column(length = 1000) // description might be long
    private String description;

    @Column(name = "duration")
    private String duration;

    @Column(name = "actual_price")
    private String actualPrice;

    @Column(name = "discounted_price")
    private String discountedPrice;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "updated_at")
    private Long updatedAt;
}
