package com.tour.management.tour_package;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourPackageApplicationTests {

	@Test
	void contextLoads() {
	}

}
