#!/bin/bash

# ✅ Load environment variables from .env safely
if [ -f .env ]; then
  set -o allexport
  source .env
  set +o allexport
else
  echo "❌ .env file not found!"
  exit 1
fi

# ✅ Export for AWS CLI compatibility (no spaces around =)
export AWS_ACCESS_KEY_ID="${AWS_GIT_ACCESS_KEY}"
export AWS_SECRET_ACCESS_KEY="${AWS_GIT_SECRET_KEY}"
export AWS_DEFAULT_REGION="${AWS_GIT_REGION}"

# ✅ Debug info (no secrets!)
echo "✅ AWS credentials loaded"
echo "🔐 AWS_ACCESS_KEY_ID: ${AWS_ACCESS_KEY_ID:0:4}********"
echo "🌍 AWS_DEFAULT_REGION: ${AWS_DEFAULT_REGION}"

# --- GIT COMMANDS ---
echo "🔄 Adding all files..."
git add .

echo "✏️ Enter your commit message:"
read commit_msg

git commit -m "$commit_msg"

echo "🚀 Pushing to current branch..."
git push