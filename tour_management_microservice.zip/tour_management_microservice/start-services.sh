#!/bin/bash
set -e

# Function to wait for service health
wait_for_health() {
  local service=$1
  local url=$2
  local timeout=$3
  local elapsed=0

  echo "⏳ Waiting for $service to be healthy at $url ..."
  until curl -s $url | grep '"status":"UP"' > /dev/null; do
    if [ $elapsed -ge $timeout ]; then
      echo " $service failed to become healthy within $timeout seconds."
      echo " Showing logs for $service:"
      docker compose logs $service
      exit 1
    fi
    echo "   $service not ready yet... ($elapsed/$timeout seconds)"
    sleep 5
    elapsed=$((elapsed + 5))
  done
  echo " $service is healthy!"
}

# Step 1: Build services
echo " Building all services..."
docker compose down service-registry middle-ware tour-package api-gateway
docker compose build service-registry middle-ware tour-package api-gateway

# Step 2: Start service-registry
echo " Starting service-registry..."
docker compose up -d service-registry
wait_for_health "service-registry" "http://localhost:8761/actuator/health" 180

echo " Waiting 10 seconds before starting middle-ware..."
sleep 10

# Step 3: Start middle-ware (NO DEPS)
echo " Starting middle-ware..."
docker compose up -d --no-deps middle-ware
wait_for_health "middle-ware" "http://localhost:8088/actuator/health" 180

echo " Waiting 10 seconds before starting tour-package..."
sleep 10

# Step 4: Start tour-package (NO DEPS)
echo " Starting tour-package..."
docker compose up -d --no-deps tour-package
wait_for_health "tour-package" "http://localhost:8081/actuator/health" 180

echo " Waiting 10 seconds before starting api-gateway..."
sleep 10

# Step 5: Start api-gateway (NO DEPS)
echo " Starting api-gateway..."
docker compose up -d --no-deps api-gateway
wait_for_health "api-gateway" "http://localhost:8080/actuator/health" 180

echo " Starting Zipkin..."
docker run -d -p 9411:9411 openzipkin/zipkin-slim

echo " All services are built, started, and healthy!"
