package com.tour.management.middle_ware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootTest
class MiddleWareApplicationTests {

	@Test
	void contextLoads() {
	}

}
