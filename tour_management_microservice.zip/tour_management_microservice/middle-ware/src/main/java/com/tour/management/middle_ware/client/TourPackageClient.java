package com.tour.management.middle_ware.client;

import com.tour.management.middle_ware.config.APIResponse;
import com.tour.management.middle_ware.constants.EndpointConstants;
import com.tour.management.middle_ware.constants.VariableConstants;
import com.tour.management.middle_ware.dto.RequetUpdateTourPackage;
import com.tour.management.middle_ware.dto.TourPackageDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@FeignClient(name = "tour-package", url = "http://tour-package:8081/api/tours/")
public interface TourPackageClient {

    @PostMapping(EndpointConstants.ADD_TOUR_PACKAGE)
    ResponseEntity<APIResponse> addNewTourPackageWithLocation(@RequestBody TourPackageDto tourPackageDto, @RequestParam(VariableConstants.USER_NAME) String userName);

    @PutMapping(EndpointConstants.UPDATE_TOUR_PACKAGE)
    ResponseEntity<APIResponse> updateExitTourPackage(@RequestBody RequetUpdateTourPackage requetUpdateTourPackage, @RequestParam(VariableConstants.USER_NAME) String userName);

    @DeleteMapping(EndpointConstants.DELETE_TOUR_PACKAGE)
    ResponseEntity<APIResponse> deleteExitTourPackage(@PathVariable(VariableConstants.ID) Integer id, @RequestParam(VariableConstants.USER_NAME) String userName);

    @GetMapping(EndpointConstants.GET_ALL_TOUR_PACKAGE)
    ResponseEntity<APIResponse> listAllPackages(@RequestParam(VariableConstants.USER_NAME) String userName);

    @GetMapping
    ResponseEntity<APIResponse> getTourPackageById(@RequestParam(VariableConstants.ID) Integer id, @RequestParam(VariableConstants.USER_NAME) String userName);

    @GetMapping(EndpointConstants.GET_TOUR_PACKAGE_LOCATION)
    ResponseEntity<APIResponse> getTourPackageByLocation(@PathVariable(VariableConstants.LOCATION) String location, @RequestParam(VariableConstants.USER_NAME) String userName);

    @PutMapping(EndpointConstants.UPLOAD_TOUR_PACKAGE_IMAGE)
    ResponseEntity<APIResponse> uploadTourPackageImage(@RequestParam(VariableConstants.IMAGE) MultipartFile file, @RequestParam(VariableConstants.ID) Integer id, @RequestParam(VariableConstants.USER_NAME) String userName);

}
