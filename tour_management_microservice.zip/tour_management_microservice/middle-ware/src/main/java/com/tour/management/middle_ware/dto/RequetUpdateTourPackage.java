package com.tour.management.middle_ware.dto;

public record RequetUpdateTourPackage(
        Integer id,
        String location,
        String image,
        String discountInPercentage,
        String title,
        String description,
        String duration,
        String actualPrice,
        String discountedPrice) {
}
