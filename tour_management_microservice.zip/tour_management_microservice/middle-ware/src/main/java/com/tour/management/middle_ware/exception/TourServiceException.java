package com.tour.management.middle_ware.exception;

import org.springframework.http.HttpStatus;

import java.util.Map;

public class TourServiceException extends RuntimeException {
    private final HttpStatus status;
    private final String errorCode;
    private final String path;
    private Map<String, String> errors;

    public TourServiceException(HttpStatus status, String message, String errorCode,  Map<String, String> errors,String path) {
        super(message);
        this.status = status;
        this.errorCode = errorCode;
        this.errors = errors;
        this.path = path;

    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getPath() {
        return path;
    }

    public Map<String, String> getErrors() {
        return errors;
    }
}

