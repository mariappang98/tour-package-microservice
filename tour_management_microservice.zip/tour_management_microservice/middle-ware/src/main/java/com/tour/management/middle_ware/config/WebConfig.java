package com.tour.management.middle_ware.config;

import com.tour.management.middle_ware.interceptor.RequestInterceptor;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.Arrays;
import java.util.List;

@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {


    private final RequestInterceptor requestInterceptor;
    List<String> END_POINT_WHITE_LISTS = Arrays.asList(
            "/api/v1/auth/customer/login",
            "/api/v1/auth/customer/signup",
            "/tour-package/default",
            "/api-gateway/default",
            "/swagger-ui/index.html",
            "/swagger-ui.html");

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(requestInterceptor)
                .excludePathPatterns(END_POINT_WHITE_LISTS);       // apply to all endpoints

    }
}

