package com.tour.management.middle_ware.services.service;

import com.tour.management.middle_ware.config.APIResponse;
import com.tour.management.middle_ware.dto.RequestDTO;
import org.springframework.http.ResponseEntity;

public interface AuthService {

    ResponseEntity<APIResponse> signUp(RequestDTO requestSignupDTO);

    ResponseEntity<APIResponse> login(RequestDTO requestLoginDTO);
}
