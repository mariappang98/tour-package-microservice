package com.tour.management.middle_ware.services.service_impl;

import com.tour.management.middle_ware.config.APIResponse;
import com.tour.management.middle_ware.config.ErrorResponse;
import com.tour.management.middle_ware.constants.Messages;
import com.tour.management.middle_ware.dto.RequestDTO;
import com.tour.management.middle_ware.dto.RequestMeta;
import com.tour.management.middle_ware.entity.Customer;
import com.tour.management.middle_ware.exception.GlobalExceptionHandler;
import com.tour.management.middle_ware.repo.AuthRepo;
import com.tour.management.middle_ware.security.JWTToken;
import com.tour.management.middle_ware.services.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final RequestMeta requestMeta;

    private final AuthRepo authRepo;

    private final JWTToken jwtToken;

    private static final Logger LOGGER
            = LoggerFactory.getLogger(AuthServiceImpl.class);


    @Override
    public ResponseEntity<APIResponse> signUp(RequestDTO requestSignupDTO) {
        if (requestMeta != null) {
            LOGGER.warn("Signup attempt with empty username");

            boolean userExists = authRepo.findAll().stream()
                    .anyMatch(data -> data.getUserName().equals(requestSignupDTO.getUserName()));

            if (!userExists) {
                Customer newCustomer = new Customer();
                newCustomer.setUserName(requestSignupDTO.getUserName());
                newCustomer.setPassword(requestSignupDTO.getPassword());
                newCustomer.setCreatedAt(System.currentTimeMillis() / 1000);

                authRepo.save(newCustomer);

                LOGGER.info("New customer created successfully: {}", newCustomer.getUserName());
                return ResponseEntity.status(HttpStatus.CREATED).body(new APIResponse(Messages.USER_CREATION_SUCCESS,new ArrayList<>()));
            } else {
                LOGGER.error("Signup failed: User already exists - {}", requestSignupDTO.getUserName());
                return ResponseEntity.status(HttpStatus.CONFLICT).body(APIResponse.builder()
                        .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                        .message(Messages.USER_ALREADY_EXISTS)
                        .timestamp(LocalDateTime.now().toString())
                        .path(GlobalExceptionHandler.getCurrentRequestPath())
                        .build());
            }
        } else {
            LOGGER.error("Signup failed: Invalid request, username field is not empty -> {}", requestMeta.getUserName());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.USER_DOES_NOT_EXIST)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }
    }

    @Override
    public ResponseEntity<APIResponse> login(RequestDTO requestLoginDTO) {
        LOGGER.info("Login attempt: {}", requestLoginDTO.getUserName());

        Customer customer = authRepo.findAll().stream()
                .filter(data -> data.getUserName().equals(requestLoginDTO.getUserName()))
                .findAny().get();

        if (customer == null) {
            LOGGER.error("Login failed: User not found - {}", requestLoginDTO.getUserName());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.USER_DOES_NOT_EXIST)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }

        if (!customer.getPassword().equals(requestLoginDTO.getPassword())) {
            LOGGER.error("Login failed: Invalid password for {}", requestLoginDTO.getUserName());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(APIResponse.builder()
                    .errorCode(GlobalExceptionHandler.generateRandomErrorCode("ERR_"))
                    .message(Messages.INVALID_CREDENTIALS)
                    .timestamp(LocalDateTime.now().toString())
                    .path(GlobalExceptionHandler.getCurrentRequestPath())
                    .build());
        }

        // ✅ Generate JWT
        String token = jwtToken.generateToken(customer.getUserName());
        System.out.println(customer.getUserName()+token);
        LOGGER.info("Login successful: {}", requestLoginDTO.getUserName());
        return ResponseEntity.status(HttpStatus.CREATED).body(new APIResponse(Messages.USER_LOGIN_SUCCESS, token));
    }
}
