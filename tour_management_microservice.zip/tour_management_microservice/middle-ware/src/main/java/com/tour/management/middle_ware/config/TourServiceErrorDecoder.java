package com.tour.management.middle_ware.config;

import com.tour.management.middle_ware.exception.TourServiceException;
import feign.Response;
import feign.codec.ErrorDecoder;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class TourServiceErrorDecoder implements ErrorDecoder {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public Exception decode(String methodKey, Response response) {
        try {
            Map<String, Object> errorBody = objectMapper.readValue(
                    response.body().asInputStream(),
                    Map.class
            );

            String message = (String) errorBody.getOrDefault("message", "Unknown error");
            String errorCode = (String) errorBody.getOrDefault("errorCode", "ERR_UNKNOWN");
            Map<String, String> error = new HashMap<>();
            Object errorObj = errorBody.get("error");
            if (errorObj instanceof Map<?, ?>) {
                error = ((Map<?, ?>) errorObj).entrySet().stream()
                        .filter(e -> e.getKey() instanceof String && e.getValue() instanceof String)
                        .collect(Collectors.toMap(
                                e -> (String) e.getKey(),
                                e -> (String) e.getValue()
                        ));
            }            String path = (String) errorBody.getOrDefault("path", "");

            return new TourServiceException(
                    HttpStatus.valueOf(response.status()),
                    message,
                    errorCode,
                    error,
                    path

            );

        } catch (IOException e) {
            return new RuntimeException("Failed to parse error from Tour Service");
        }
    }
}

