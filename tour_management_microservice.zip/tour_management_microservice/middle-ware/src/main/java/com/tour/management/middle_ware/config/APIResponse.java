package com.tour.management.middle_ware.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.springframework.stereotype.Component;


@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
public class APIResponse {

    private String message;
    private Object data;
    private String errorCode;
    private String error;
    private String timestamp;
    private String path;

    public APIResponse(String message, Object data) {
        this.message = message;
        this.data = data;
    }

}
