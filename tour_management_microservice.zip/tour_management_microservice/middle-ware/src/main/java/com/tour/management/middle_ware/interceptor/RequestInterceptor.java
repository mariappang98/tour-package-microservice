package com.tour.management.middle_ware.interceptor;

import com.tour.management.middle_ware.dto.RequestMeta;
import com.tour.management.middle_ware.security.JWTToken;
import io.jsonwebtoken.Claims;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;


@Component
@RequiredArgsConstructor
public class RequestInterceptor implements HandlerInterceptor {


    private final JWTToken jwtToken;

    private final RequestMeta requestMeta;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String authToken = request.getHeader("Authorization");

        if (authToken == null || !authToken.startsWith("Bearer")) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("Missing or invalid Authorization header");
            return false;
        }
        try {

            Claims claims = jwtToken.verifyToken(authToken);
            String userName = claims.getIssuer();
            requestMeta.setUserName(userName);
        } catch (Exception e) {
            e.getStackTrace();
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("Invalid or expired token");
            return false;
        }
        return true;
    }
}
