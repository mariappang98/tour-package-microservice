package com.tour.management.middle_ware.controller;


import com.tour.management.middle_ware.client.TourPackageClient;
import com.tour.management.middle_ware.config.APIResponse;
import com.tour.management.middle_ware.constants.EndpointConstants;
import com.tour.management.middle_ware.constants.VariableConstants;
import com.tour.management.middle_ware.dto.RequestMeta;
import com.tour.management.middle_ware.dto.RequetUpdateTourPackage;
import com.tour.management.middle_ware.dto.TourPackageDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping(EndpointConstants.BASE_URL)
@RequiredArgsConstructor
public class TourPackageClientController {

    private final TourPackageClient tourPackageClient;

    private final RequestMeta requestMeta;

    @PostMapping(EndpointConstants.ADD_TOUR_PACKAGE)
    ResponseEntity<APIResponse> addNewTourPackageWithLocation(@RequestBody TourPackageDto tourPackageDto){
        return tourPackageClient.addNewTourPackageWithLocation(tourPackageDto,requestMeta.getUserName());
    }

    @PutMapping(EndpointConstants.UPDATE_TOUR_PACKAGE)
    ResponseEntity<APIResponse> updateExitTourPackage(@RequestBody RequetUpdateTourPackage requetUpdateTourPackage){
        return tourPackageClient.updateExitTourPackage(requetUpdateTourPackage,requestMeta.getUserName());
    }

    @DeleteMapping(EndpointConstants.DELETE_TOUR_PACKAGE)
    ResponseEntity<APIResponse> deleteExitTourPackage(@PathVariable(VariableConstants.ID) Integer id){
        return tourPackageClient.deleteExitTourPackage(id,requestMeta.getUserName());
    }

    @GetMapping(EndpointConstants.GET_ALL_TOUR_PACKAGE)
    ResponseEntity<APIResponse> listAllPackages(){
        return tourPackageClient.listAllPackages(requestMeta.getUserName());
    }

    @GetMapping
    ResponseEntity<APIResponse> getTourPackageById(@RequestParam(VariableConstants.ID) Integer id){
        return tourPackageClient.getTourPackageById(id,requestMeta.getUserName());
    }

    @GetMapping(EndpointConstants.GET_TOUR_PACKAGE_LOCATION)
    ResponseEntity<APIResponse> getTourPackageByLocation(@PathVariable(VariableConstants.LOCATION) String location){
        return tourPackageClient.getTourPackageByLocation(location,requestMeta.getUserName());
    }

    @PutMapping(value = EndpointConstants.UPLOAD_TOUR_PACKAGE_IMAGE)
    ResponseEntity<APIResponse> uploadTourPackageImage(@RequestParam(VariableConstants.IMAGE) MultipartFile image, @RequestParam(VariableConstants.ID) Integer id){
        return tourPackageClient.uploadTourPackageImage(image,id,requestMeta.getUserName());
    }
}
