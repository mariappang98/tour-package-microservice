package com.tour.management.middle_ware.dto;

public record TourPackageDto(
        String location,
        String image,
        String discountInPercentage,
        String title,
        String description,
        String duration,
        String actualPrice,
        String discountedPrice) {
}
