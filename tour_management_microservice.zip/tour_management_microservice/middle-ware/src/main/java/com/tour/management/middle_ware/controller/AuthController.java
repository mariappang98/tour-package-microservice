package com.tour.management.middle_ware.controller;

import com.tour.management.middle_ware.config.APIResponse;
import com.tour.management.middle_ware.constants.EndpointConstants;
import com.tour.management.middle_ware.dto.RequestDTO;
import com.tour.management.middle_ware.services.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(EndpointConstants.AUTH_BASE_URL)
@RequiredArgsConstructor
public class AuthController {

    private static final Logger LOGGER
            = LoggerFactory.getLogger(AuthController.class);

    private final AuthService authService;


    @PostMapping(EndpointConstants.SIGN_UP_URL)
   // @Operation(summary = "Customer signup")
    ResponseEntity<APIResponse> signUp(@RequestBody RequestDTO requestSignupDTO){
        LOGGER.info("Auth signup: {}", requestSignupDTO);
        return authService.signUp(requestSignupDTO);
    }


    @PostMapping(EndpointConstants.LOGIN_URL)
   /// @Operation(summary = "Customer login")
    ResponseEntity<APIResponse> login(@RequestBody RequestDTO requestLoginDTO){
        LOGGER.info("Auth login: {}", requestLoginDTO);
        return authService.login(requestLoginDTO);
    }

}
