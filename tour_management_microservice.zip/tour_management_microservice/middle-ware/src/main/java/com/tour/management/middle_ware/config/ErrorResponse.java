package com.tour.management.middle_ware.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
public class ErrorResponse {
    private String errorCode;
    private String message;
    private String timestamp;
    private String path;
}
